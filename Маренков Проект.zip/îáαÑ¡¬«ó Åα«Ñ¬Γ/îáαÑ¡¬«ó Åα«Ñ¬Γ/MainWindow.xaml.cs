﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Маренков_Проект
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        class ProductTable
        {
            public ProductTable(int Id, string Artist, string Album, int Date)
            {
                this.Id = Id;
                this.Artist = Artist;
                this.Album = Album;
                this.Date = Date;
            }
        public int Id { get; set; }
        public string Artist { get; set; }

        public string Album { get; set; }

        public int Date { get; set; }
        }

        private void grid_Loaded(object sender, RoutedEventArgs e)
        {
            List<ProductTable> result= new List<ProductTable>(3);
            result.Add(new ProductTable(1, "Sonic Youth", "Sister", 1987));
            Grid.ItemSource = result;
        }

        private void grid_Mouse_Up(object sender, MouseButtonEventArgs e)
        {
            ProductTable path = Grid.SelectedItem as ProductTable;
            MessageBox.Show(" ID: " + path.Id + "\n Исполнитель: " + path.Artist + "\n Альбом" + path.Album + "\n Дата: " + path.Date);
        }
    }
}
